/*
Copyright (c) 2003-2019, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'templates', 'ko', {
	button: '템플릿',
	emptyListMsg: '(템플릿이 없습니다)',
	insertOption: '현재 내용 바꾸기',
	options: '템플릿 옵션',
	selectPromptMsg: '에디터에서 사용할 템플릿을 선택하십시오',
	title: '내용 템플릿'
} );
