/*
Copyright (c) 2003-2019, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'templates', 'cy', {
	button: 'Templedi',
	emptyListMsg: '(Dim templedi wedi\'u diffinio)',
	insertOption: 'Amnewid y cynnwys go iawn',
	options: 'Opsiynau Templedi',
	selectPromptMsg: 'Dewiswch dempled i\'w agor yn y golygydd',
	title: 'Templedi Cynnwys'
} );
