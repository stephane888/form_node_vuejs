/*
Copyright (c) 2003-2019, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'templates', 'nb', {
	button: 'Maler',
	emptyListMsg: '(Ingen maler definert)',
	insertOption: 'Erstatt gjeldende innhold',
	options: 'Alternativer for mal',
	selectPromptMsg: 'Velg malen du vil åpne i redigeringsverktøyet:',
	title: 'Innholdsmaler'
} );
