/*
Copyright (c) 2003-2019, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'templates', 'tr', {
	button: 'Şablonlar',
	emptyListMsg: '(Belirli bir şablon seçilmedi)',
	insertOption: 'Mevcut içerik ile değiştir',
	options: 'Şablon Seçenekleri',
	selectPromptMsg: 'Düzenleyicide açmak için lütfen bir şablon seçin.<br>(hali hazırdaki içerik kaybolacaktır.):',
	title: 'İçerik Şablonları'
} );
