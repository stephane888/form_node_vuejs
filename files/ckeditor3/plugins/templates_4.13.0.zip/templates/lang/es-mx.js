/*
Copyright (c) 2003-2019, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'templates', 'es-mx', {
	button: 'Plantillas',
	emptyListMsg: '(Sin plantilla definida)',
	insertOption: 'Reemplazar contenido actual',
	options: 'Opciones de la plantilla',
	selectPromptMsg: 'Por favor selecciona una plantilla para abrir en el editor',
	title: 'Contenido de las plantillas'
} );
