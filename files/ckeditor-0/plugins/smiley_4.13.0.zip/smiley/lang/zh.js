/*
Copyright (c) 2003-2019, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'smiley', 'zh', {
	options: '表情符號選項',
	title: '插入表情符號',
	toolbar: '表情符號'
} );
